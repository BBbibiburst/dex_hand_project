#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
mkdir -p build/body build/back build/front
for pass in 1 2 3 4; do
 xelatex -file-line-error --shell-escape -interaction=nonstopmode -halt-on-error -output-directory=build thesis.tex
 if [ "$pass" = 1 ]; then bibtex build/thesis; fi
done
