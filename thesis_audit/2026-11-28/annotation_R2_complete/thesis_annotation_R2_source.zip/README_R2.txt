R2完整活动源文件与所用图稿。进入thesis目录，以XeLaTeX + BibTeX + XeLaTeX两次或更多编译thesis.tex。需要hithesis相关TeX包、Fandol/TeX Gyre字体。未附TeX发行版、私有Windows字体、实验数据或模型。主文件保持本轮之前组织。初稿待人工审核，非冻结版。
